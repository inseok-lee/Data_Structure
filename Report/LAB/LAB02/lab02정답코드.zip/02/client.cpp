#include <iostream>
#include "sorted.h"
using namespace std;


void MergeList(SortedType list1, SortedType list2, SortedType& result) {
	list1.ResetList();
	list2.ResetList();
	result.ResetList();

	int sizeOfList1 = list1.LengthIs();
	int sizeOfList2 = list2.LengthIs();


	for (int i = 0; i < sizeOfList1; i++) {
		ItemType tempItem;
		list1.GetNextItem(tempItem);
		result.InsertItem(tempItem);
	}

	for (int i = 0; i < sizeOfList2; i++) {
		ItemType tempItem;
		list2.GetNextItem(tempItem);
		result.InsertItem(tempItem);
	}
}

int main() {

	SortedType s_list1, s_list2, s_list3; //����Ʈ ����
	ItemType item1, item2, item3, item4, item5; //...

	item1.Initialize(1);
	item2.Initialize(3);
	item3.Initialize(5);
	item4.Initialize(2);
	item5.Initialize(4);
	s_list1.InsertItem(item1);
	s_list1.InsertItem(item2);
	s_list1.InsertItem(item3);
	s_list2.InsertItem(item4);
	s_list2.InsertItem(item5);

	MergeList(s_list1, s_list2, s_list3);

	ItemType tempItem;
	for (int i = 0; i < s_list3.LengthIs(); i++) {
		s_list3.GetNextItem(tempItem);
		tempItem.Print(cout);
	}


	return 0;
}
