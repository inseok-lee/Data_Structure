template<class VertexType>
GraphType<VertexType>::GraphType()
// Post: Arrays of size 50 are dynamically allocated for  
//       marks and vertices.  numVertices is set to 0; 
//       maxVertices is set to 50.
{
  numVertices = 0;
  maxVertices = 50;
  vertices = new VertexType[50];
  marks = new bool[50];
}

template<class VertexType>
GraphType<VertexType>::GraphType(int maxV)
// Post: Arrays of size maxV are dynamically allocated for  
//       marks and vertices.  
//       numVertices is set to 0; maxVertices is set to maxV.
{
  numVertices = 0;
  maxVertices = maxV;
  vertices = new VertexType[maxV];
  marks = new bool[maxV];
}

template<class VertexType>
// Post: arrays for vertices and marks have been deallocated.
GraphType<VertexType>::~GraphType()
{
  delete [] vertices;
  delete [] marks;
}
const int NULL_EDGE = 0;

template<class VertexType>
void GraphType<VertexType>::AddVertex(VertexType vertex)
// Post: vertex has been stored in vertices.
//       Corresponding row and column of edges has been set 
//       to NULL_EDGE.
//       numVertices has been incremented.
{
  vertices[numVertices] = vertex;

  for (int index = 0; index < numVertices; index++)
  {
    edges[numVertices][index] = NULL_EDGE;
    edges[index][numVertices] = NULL_EDGE;
  }
  numVertices++;
}
template<class VertexType>
int IndexIs(VertexType* vertices, VertexType vertex)
// Post: Returns the index of vertex in vertices.
{
  int index = 0;

  while (!(vertex == vertices[index]))
    index++;  
  return index;
}       

template<class VertexType>
void GraphType<VertexType>::AddEdge(VertexType fromVertex,
     VertexType toVertex, int weight)
// Post: Edge (fromVertex, toVertex) is stored in edges.
{
  int row;
  int col;

  row = IndexIs(vertices, fromVertex);
  col = IndexIs(vertices, toVertex)
  edges[row][col] = weight;
}

template<class VertexType>
int GraphType<VertexType>::WeightIs
     (VertexType fromVertex, VertexType toVertex)
// Post: Returns the weight associated with the edge 
//       (fromVertex, toVertex).
{
  int row;
  int col;

  row = IndexIs(vertices, fromVertex);
  col = IndexIs(vertices, toVertex);
  return edges[row][col];
}
template<class VertexType>
void GraphType<VertexType>::GetToVertices(VertexType vertex, 
     QueType<VertexType>& adjVertices)
// Post: 
{
  int fromIndex;
  int toIndex;

  fromIndex = IndexIs(vertices, vertex);
  for (toIndex = 0; toIndex < numVertices; toIndex++)
    if (edges[fromIndex][toIndex] != NULL_EDGE)
      adjVertices.Enqueue(vertices[toIndex]);
}     



                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             2  U  ?  ?  ?  ?       5  M  O  P  k  ?  ?  ?  0  2  E  [  ~  ?  ?  ?  ?  ?      ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?                             2  U  ?  ?  ?  ?       5  M  O  P  k  ?  ?  ?  0  2  E  [  ~  ?  ?  ?  ?  ?      0  C  E  ^  _  z  ?  ?    4  _  a  ?  ?  ?  ?  ?  	  	  '	  )	  D	  y	  ?  ?  ?  ?  ?  ?  
  
  
  *
  e
  ?  ?  ?  ?  ?  ?    (  D  F  G  b  ?  ?  ?        '  (  O  t  ?  ?  ?  ?  
  
  
  -
  <
  =
  f
  ?  ?  ?    ����������������������������������������������������������������������������������������������������    d  0  C  E  ^  _  z  ?  ?    4  _  a  ?  ?  ?  ?  ?  	  	  '	  )	  D	  y	  ?  ?  ?  ?  ?  ?  ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?                        ?  
  
  
  *
  e
  ?  ?  ?  ?  ?  ?    (  D  F  G  b  ?  ?  ?        '  (  O  t  ?  ?  ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?                        ?  ?  ?  
  
  
  -
  <
  =
  f
  ?  ?  ?          ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?            ?                                                                                                                                                                                                                                                            ��                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ��/ ��=!?"?#��$��%?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
  [      4  @? 4    N o r m a l       CJ OJ PJ QJ mH	H    H   	 H e a d i n g   1     $�� ? @&  5�CJ KH OJ QJ  B    B   	 H e a d i n g   2     $�� ? @& 5?�OJ QJ B    B    H e a d i n g   3 , H 3     $�� ? @& OJ QJ             < A@?? <    D e f a u l t   P a r a g r a p h   F o n t             0 ? ? 0    Q u e s t i o n      CJ OJ QJ 0 ? 0    t e x t   	  $�v  CJ OJ  QJ  ? ??    a l g   ?  $$*$��$d %d &d 'd 
? !   @`�??? 	 
@`�
???  @`�???  @`�??? $                                   OJ PJ  QJ l ? "l    A l g   C  ��?�h$d %d &d 'd 
?   ?p?@?          CJ OJ PJ  QJ 4 Z` 24   
 P l a i n   T e x t      CJ OJ QJ     h
    (   ����    ��       ��         ?  h
                 
        ?  ?                                 
      &   0   2   ;   <   F   I   R   ?   ?   ?   ?   ?   ?     
  %  /  C  G  _  i  k  t  u    ?  ?  ?  ?  ?  ?  ?        *  .  4  ?  G  R  U  Y  l  v  w  {  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?        n  x    ?  ?  ?  ?  ?  ?  ?  =  H  l  w  ?  ?  ?  ?  ?  ?  ?      %  8  B  H  O  P  Z  f  p  ?  ?    (  /  8  9  C  F  M  N  X  Y  c  j  t  u  }  ?  ?  ?  ?  ?  ?  ?  ?  ?      	        &  5  8  V  `  f  o  p  z  }  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?        "  %  0  7  B  L  Q  T  W  ^  i  q  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?   	  	  	  "	  +	  3	  :	  ?	  H	  K	  R	  m	  t	  z	  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  
                                                                                                                                                                                                                 ��   	 N e l l   D a l e Z h a r d   d r i v e : D e s k t o p   F o l d e r : B o o k s : p r i n t e d : C + +   P l u s : L a b ,   C + +   3 r d : C h a p t e r 9 : G r a p h : G r a p h T y p e . c p p �@�       ��(	? ?                4 A h?       
  `   @     G?                        T i m e s   N e w   R o m a n   5?                           �    S y m b o l   3?                        A r i a l   3?                                T i m e s   ;?                                H e l v e t i c a   9?                                P a l a t i n o   ??  	                      C o u r i e r   N e w   "  q?  ?  h    ?sF?sF        ?  ?                             ?                                                                                                                                                                                                                                                                                                                            ??? ? � 0              ?                                                                     G��        # i n c l u d e   " G r a p h T y p e       	 N e l l   D a l e 	 N e l l   D a l e                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ?  
                    ?��?h�� +'��0   h        ?      ?      ?      ?      ?      ?      ?   	   ?        
   $     0  
   <     H     P     X     `     '        #include "GraphType        inc   
   Nell Dale Gr       ell      Normal l   
   Nell Dale Gr      1 ll      Microsoft Word 8.0  @    F?    @    |?��?@    Y��?         ?     ?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ?  
                    ��?.�� +,��D   ��?.�� +,��@  ?         h      p      |      ?      ?      ?      ?      ?      ?      ?   
   ?      ?      '         l u               ?     :                                     #include "GraphType            Title         ?                 6      >         
   _PID_GUID    '  A   N   { C C F E D E 2 B - 1 E 7 8 - 1 1 6 8 - 9 5 4 E - 0 0 3 0 6 5 5 0 0 E 5 6 }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       	   
         
                        ?��                     ?��          !   "   #   $   ?��&   '   (   )   *   +   ,   ?��?��/   ?��?��?��������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������R o o t   E n t r y                                              ��������   	     ?      F            �#?c��1   �       1 T a b l e                                                       ������������                                              W o r d D o c u m e n t                                             ��������                                        (       S u m m a r y I n f o r m a t i o n                           (       ����                                               D o c u m e n t S u m m a r y I n f o r m a t i o n           8 ������������                                    %           C o m p O b j                                                        ����                                        X       O b j e c t P o o l                                               ������������                    �#?c���#?c��                                                                                ������������                                                   ?�������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������� ?  ����	     ?      F   Microsoft Word Document ?��NB6W   Word.Document.8                                                                                                                                                                                                                                                                                                                                                                                                                                             