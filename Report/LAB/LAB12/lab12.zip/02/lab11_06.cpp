#include <iostream>
using namespace std;

#include "GraphType.h"

int main() {

	GraphType<char*> graph;

	graph.AddVertex((char*)"dog");
	graph.AddVertex((char*)"cat");
	graph.AddVertex((char*)"animal");
	graph.AddVertex((char*)"vertebrate");
	graph.AddVertex((char*)"oyster");
	graph.AddVertex((char*)"shellfish");
	graph.AddVertex((char*)"invertebrate");
	graph.AddVertex((char*)"crab");
	graph.AddVertex((char*)"poodle");
	graph.AddVertex((char*)"monkey");
	graph.AddVertex((char*)"banana");
	graph.AddVertex((char*)"dalmatian");
	graph.AddVertex((char*)"dachshund");

	graph.AddEdge((char*)"vertebrate",(char*)"dachshund", 10);
	graph.AddEdge((char*)"invertebrate", (char*)"animal", 10);
	graph.AddEdge((char*)"dog", (char*)"vertebrate", 10);
	graph.AddEdge((char*)"cat", (char*)"vertebrate", 10);
	graph.AddEdge((char*)"monkey", (char*)"vertebrate", 10);
	graph.AddEdge((char*)"shellfish", (char*)"invertebrate", 10);
	graph.AddEdge((char*)"crab", (char*)"shellfish", 10);
	graph.AddEdge((char*)"oyster", (char*)"invertebrate", 10);
	graph.AddEdge((char*)"poodle", (char*)"dog", 10);
	graph.AddEdge((char*)"dalmatian", (char*)"dog", 10);
	graph.AddEdge((char*)"dachshund", (char*)"dog", 10);

	graph.DeleteEdge((char *)"poodle", (char*) "dog");
	cout << "Weight of poodle to dog is " << graph.WeightIs((char*)"poodle", (char*)"dog") << endl;

	cout << endl << "GetToVertices(dog, queue)" << endl;
	QueType<char*> queue;
	graph.GetToVertices((char*)"dog", queue);
	while (!queue.IsEmpty()) {
		char* item;
		queue.Dequeue(item);
		cout << item << endl;
	}
	return 0;
}