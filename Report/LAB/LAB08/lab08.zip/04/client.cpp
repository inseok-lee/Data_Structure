#include <iostream>
using namespace std;

#define MAX_ROWS 10
#define MAX_COLS 10


static int mat[MAX_ROWS][MAX_COLS];

int NumPaths_A(int row, int col, int n) {

	if (row == col)
		cout << "same" << endl;
	if (row == n || col == n)
		return 1;

	else {
		
		return NumPaths_A(row + 1, col, n) + NumPaths_A(row, col + 1, n);
	}
}


int NumPaths_B(int row, int col, int n) {

	
	if (mat[row][col] == -1) {
		
		if (row == col)
			cout << "(" << row << ',' << col << ")" << endl;

		if (row == n || col == n) {

			mat[row][col] = 1;
			
			return 1;
		}
		else {
			
			mat[row][col] = NumPaths_B(row + 1, col, n) + NumPaths_B(row, col + 1, n);
			return mat[row][col];
		}
		

	}


	return mat[row][col];
}

int main() {

	int  n = 3;

	cout << NumPaths_A(1, 1, n) << endl;

	for (int i = 0; i < MAX_ROWS; i++) {

		for (int j = 0; j < MAX_COLS; j++) {

			mat[i][j] = -1;

			
		}

	}
	

	cout << NumPaths_B(1, 1, n) << endl;

	for (int i = n ; i > 0; i--) {

		for (int j = 1; j < n + 1; j++) {

			cout << mat[i][j] << " ";

		}

		cout << '\n';
	}


	return 0;
}