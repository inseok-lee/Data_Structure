#include "QueType.h"
#include <iostream>
using namespace std;

bool Identical(QueType& que1, QueType& que2)
{
	QueType tmp1;
	QueType tmp2;
	int item1;
	int item2;
	bool flag = true;
	while (!que1.IsEmpty())
	{
		que1.Dequeue(item1);
		que2.Dequeue(item2);
		tmp1.Enqueue(item1);
		tmp2.Enqueue(item2);
		if (item1 != item2)
			flag = false;
	}
	while (!tmp1.IsEmpty()) 
	{
		tmp1.Dequeue(item1);
		que1.Enqueue(item1);
		tmp2.Dequeue(item2);
		que2.Enqueue(item2);
	}

	return flag;
}
int main()
{
	int arr1[9] = { 2, 6, 7, 4, 5, 6, 10, 15, 3 };
	int arr2[9] = { 3, 15, 10, 6, 5, 4, 7, 6, 2 };
	QueType que1(4);
	QueType que2(4);
	for (int i = 0; i < 3; i++)
	{
		que1.Enqueue(arr1[i]);
		que2.Enqueue(arr1[i]);
	}
	//bool result = Identical(que1, que2);
	bool result = que1.Identical(que2);
	if (result == true)
		cout << "TRUE" << endl;
	else
		cout << "FALSE" << endl;

	return 0;
}