#include <iostream>
#include <cstdlib>
#include "QueType.h"
using namespace std;

int Length(QueType& queue) {

	int length = 0;
	QueType tempQue;

	while (!queue.IsEmpty()) {

		ItemType item;
		queue.Dequeue(item);
		tempQue.Enqueue(item);

		length++;

	}

	while (!tempQue.IsEmpty()) {
		ItemType item;
		tempQue.Dequeue(item);
		queue.Enqueue(item);
	}

	return length;

}

int main() {

	QueType queue(5);

	ItemType item;

	queue.Enqueue(7);
	queue.Enqueue(4);
	queue.Enqueue(5);
	queue.Enqueue(6);
	queue.Enqueue(9);
	queue.Dequeue(item);
	queue.Dequeue(item);
	queue.Enqueue(6);
	queue.Enqueue(9);

	cout << "Queue length : " << Length(queue) << endl;
	cout << "Queue length : " << queue.Length() << endl;

	while (!queue.IsEmpty()) {

		queue.Dequeue(item);
		cout << item << ' ';

	}
	cout << endl;


	return 0;
}