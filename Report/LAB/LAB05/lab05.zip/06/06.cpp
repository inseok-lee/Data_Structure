#include <iostream>
#include <cstdlib>
#include "QueType.h"
using namespace std;

int main() {

	QueType queue;
	ItemType item;

	queue.Enqueue(5);
	queue.Enqueue(4);
	queue.Enqueue(3);
	queue.Enqueue(2);
	queue.Enqueue(1);

	queue.MinDequeue(item);
	cout << "minItem : " << item << endl;
	queue.MinDequeue(item);
	cout << "minItem : " << item << endl;

	queue.Enqueue(1);
	queue.Enqueue(2);


	for(int i = 0; i < 5; i++) {

		queue.MinDequeue(item);

		cout << item << " ";
	}


	return 0;
}