#include <iostream>
#include "QueType.h"
using namespace std;

void Replace(QueType& queue, int oldItem, int newItem) {

	QueType tempQueue;

	while (!queue.IsEmpty()) {

		int item;

		queue.Dequeue(item);

		if (item == oldItem) {
			tempQueue.Enqueue(newItem);
		}
		else {
			tempQueue.Enqueue(item);
		}

	}

	while (!tempQueue.IsEmpty()) {

		int item;

		tempQueue.Dequeue(item);
		queue.Enqueue(item);

	}
}

int main() {

	QueType queue;

	queue.Enqueue(2);
	queue.Enqueue(6);
	queue.Enqueue(7);
	queue.Enqueue(4);
	queue.Enqueue(5);
	queue.Enqueue(6);
	queue.Enqueue(10);
	queue.Enqueue(15);
	queue.Enqueue(6);

	//Replace(queue, 6, 20); 
	queue.ReplaceItem(6, 20);
	while (!queue.IsEmpty()) {

		int item;
		queue.Dequeue(item);
		cout << item << ' ';

	}

	return 0;
}