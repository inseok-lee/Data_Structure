#include <iostream>
#include <cstdlib>
#include "QueType.h"
using namespace std;


int main() {

	QueType queue(5);

	queue.Enqueue(1);
	queue.Enqueue(2);
	queue.Enqueue(3);

	ItemType item;
	queue.Dequeue(item);

	queue.Enqueue(1);
	queue.Enqueue(2);
	queue.Enqueue(3);

	

	while (!queue.IsEmpty()) {

		ItemType item;
		queue.Dequeue(item);
		cout << item << ' ';

	}
	cout << endl;


	return 0;
}