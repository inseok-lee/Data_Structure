#include <iostream>
//#include "SortedType.h"
#include "UnsortedType.h"

using namespace std;

// A. Client함수로 작성(SortedList)
//template<class ItemType>
//void SortedMergeLists(SortedType<ItemType>& l_a, SortedType<ItemType>& l_b, SortedType<ItemType>& result);

// C. Client함수로 작성(UnsortedList)
template<class ItemType>
void UnsortedMergeLists(UnsortedType<ItemType>& l_a, UnsortedType<ItemType>& l_b, UnsortedType<ItemType>& result);


int main()
{
//    ***SortedMergeLists TEST***
//    SortedType<int> sortedL1, sortedL2, result;
//    for(int i = 0; i < 5; i++){
//        sortedL1.InsertItem(2 * i + 1);
//        sortedL2.InsertItem(2 * (i + 1));
//    }
//
////    SortedMergeLists(sortedL1, sortedL2, result); // 클라이언트
//    sortedL1.SortedMergeLists(sortedL2, result); // 멤버
//
//
//    for(int i = 0; i < 10; i++){
//        int item = 0;
//        result.GetNextItem(item);
//        cout << item << " ";
//    }
//    cout << endl;
    
    
    
//    ***UnsortedMergeLists TEST***
    UnsortedType<int> unsortedL1, unsortedL2, result;
    for(int i = 0; i < 5; i++){
        unsortedL1.InsertItem(2 * i + 1);
        unsortedL2.InsertItem(2 * (i + 1));
    }
    
//    UnsortedMergeLists(unsortedL1, unsortedL2, result); // 클라이언트
    unsortedL1.UnsortedMergeLists(unsortedL2, result); // 멤버
    
    
    for(int i = 0; i < 10; i++){
        int item = 0;
        result.GetNextItem(item);
        cout << item << " ";
    }
    cout << endl;

    return 0;
}


// A. Client함수로 작성(SortedList)
//template<class ItemType>
//void SortedMergeLists(SortedType<ItemType>& l_a, SortedType<ItemType>& l_b, SortedType<ItemType>& result){
//    l_a.ResetList();
//    l_b.ResetList();
//    result.ResetList();
//
//    int lenA = l_a.LengthIs();
//    int lenB = l_b.LengthIs();
//
//    ItemType item;
//
//    while (0 < lenA){
//        ItemType item;
//        l_a.GetNextItem(item);
//        result.InsertItem(item);
//        lenA--;
//    }
//    while (0 < lenB){
//        ItemType item;
//        l_b.GetNextItem(item);
//        result.InsertItem(item);
//        lenB--;
//    }
//}

// C. Client함수로 작성(UnSortedList)
template<class ItemType>
void UnsortedMergeLists(UnsortedType<ItemType>& l_a, UnsortedType<ItemType>& l_b, UnsortedType<ItemType>& result){
    l_a.ResetList();
    l_b.ResetList();
    result.ResetList();
    
    
    int lenA = l_a.LengthIs();
    int lenB = l_b.LengthIs();
    ItemType item;

    while (0 < lenA){
        l_a.GetNextItem(item);
        result.InsertItem(item);
        lenA--;
    }
    while (0 < lenB){
        l_b.GetNextItem(item);
        result.InsertItem(item);
        lenB--;
    }
}

