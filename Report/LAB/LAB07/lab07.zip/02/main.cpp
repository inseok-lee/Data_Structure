#include <iostream>
using namespace std;
#include "StackType.h"

int main() {

	StackType stackLL;
	StackType copyStackLL;

	stackLL.Push(1);
	stackLL.Push(2);
	stackLL.Push(3);

	stackLL.Copy(copyStackLL);

	while (!copyStackLL.IsEmpty()) {

		cout << copyStackLL.Top() << endl;
		copyStackLL.Pop();
	}

	return 0;
}