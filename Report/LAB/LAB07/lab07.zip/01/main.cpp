#include <iostream>
using namespace std;
#include "SortedType.h"

int main() {

	SortedType<int> sortedList;

	sortedList.InsertItem(5);
	sortedList.InsertItem(4);
	sortedList.InsertItem(3);
	sortedList.InsertItem(2);
	sortedList.InsertItem(1);
	
	

	sortedList.PrintReverse();

	return 0;
}