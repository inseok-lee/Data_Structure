#include <iostream>
#include "TextEditor.h"
using namespace std;

int main() {

	TextEditor editor;

	char text1[80] = "Hellow";
	char text2[80] = "World";
	editor.InsertItem(text1);
	editor.InsertItem(text2);

	editor.GoToTop();
	char text[80];
	for (int i = 0; editor.LengthIs(); i++) {
		editor.GetNextItem(text);
		cout << text << endl;
	}

	return 0;
}