#include "TextEditor.h"

TextEditor::TextEditor()  // Class constructor
{
	length = 0;
	LineType* header = new LineType;
	LineType* tailer = new LineType ;
	
	header->next = tailer;
	tailer->back = header;
	header->back = NULL;
	tailer->next = NULL;

	strcpy_s(header->info, sizeof("Top"),"Top");
	strcpy_s(tailer->info, sizeof("Bottom"), "Bottom");

	listData = header;
	currentLine = header;
	
}

TextEditor::~TextEditor()
// Class destructor
{
	MakeEmpty();
}

bool TextEditor::IsFull() const
// Returns true if there is no room for another ItemType 
//  on the free store; false otherwise.
{
	LineType* location;
	try
	{
		location = new LineType;
		delete location;
		return false;
	}
	catch (std::bad_alloc exception)
	{
		return true;
	}
}

int TextEditor::LengthIs() const
// Post: Number of items in the list is returned.
{
	return length;
}

void TextEditor::MakeEmpty()
// Post: List is empty; all items have been deallocated.
{
	LineType* tempPtr;

	while (listData != NULL)
	{
		tempPtr = listData;
		listData = listData->next;
		delete tempPtr;
	}
	length = 0;
}


void TextEditor::InsertItem(ItemType* item)
// item is in the list; length has been incremented.
{
	LineType* location;

	GoToBottom();

	location = new LineType;
	for (int i = 0; item[i] != '\0'; i++) {
		location->info[i] = item[i];
	}
	location->back = currentLine;
	location->next = currentLine->next;
	currentLine->next->back = location;
	currentLine->next = location;
	
	length++;
}



void TextEditor::ResetList()
// Post: Current position has been initialized.
{
	currentLine = NULL;
}


void TextEditor::GetNextItem(ItemType* item)
// Post:  Current position has been updated; item is current item.
{
	if (currentLine == NULL)
		currentLine = listData;
	else
		currentLine = currentLine->next;
	
	for (int i = 0; currentLine->info[i] != '\0'; i++)
		item[i] = currentLine->info[i];
}

void TextEditor::GoToTop() {

	while (currentLine->back != NULL)
		currentLine = currentLine->back;

	currentLine = currentLine->next;
}

void TextEditor::GoToBottom() {

	while (currentLine->next != NULL)
		currentLine = currentLine->next;

	currentLine = currentLine->back;
}