// ItemType.h StackDriver
const int MAX_ITEMS = 8;
typedef int ItemType;