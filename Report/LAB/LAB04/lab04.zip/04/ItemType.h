// ItemType.h StackDriver
const int MAX_ITEMS = 10;
typedef int ItemType;