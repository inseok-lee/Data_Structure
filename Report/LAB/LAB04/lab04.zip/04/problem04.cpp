#include <iostream>
#include "StackType.h"
using namespace std;

void Replace(StackType& st, ItemType old_item, ItemType new_item) {

	StackType tempStack;

	
	while (!st.IsEmpty()) {

		ItemType value = st.Top();
		st.Pop();

		if (value == old_item) {
			tempStack.Push(new_item);
		}
		else 
			tempStack.Push(value);
	}

	while (!tempStack.IsEmpty()) {

		ItemType value = tempStack.Top();
		tempStack.Pop();

		st.Push(value);

	}

}

int main() {

	StackType stack;

	stack.Push(8);
	stack.Push(3);
	stack.Push(9);
	stack.Push(8);
	stack.Push(3);
	stack.Push(7);
	stack.Push(5);
	stack.Push(3);


	Replace(stack, 3, 5);

	while (!stack.IsEmpty()) {
		ItemType item = stack.Top();
		stack.Pop();
		cout << item << endl;
	}

	return 0;
}
