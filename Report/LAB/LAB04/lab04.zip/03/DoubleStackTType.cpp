#include "DoubleStackTType.h"


// The function definitions for class StackType.

// The function definitions for class StackType.
template<class ItemType>
DoubleStack<ItemType>::DoubleStack()
{
	top_small = -1;
	top_big = MAX_ITEMS;
}

template<class ItemType>
bool DoubleStack<ItemType>::IsEmpty() const
{	
	// ***********
	return (top == -1 && top == MAX_ITEMS);
}

template<class ItemType>
bool DoubleStack<ItemType>::IsFull() const
{
	// ***********
	return ((top_small + 1) == top_big);
}

template<class ItemType>
void DoubleStack<ItemType>::Push(ItemType newItem)
{
	// ***********
	if (IsFull())
		throw FullStack();
	
	if (newItem > 1000)
		top_big--;
	else
		top_small++;

	items[top] = newItem;
}

template<class ItemType>
void DoubleStack<ItemType>::Pop()
{
	//���õ� �κ��� ���⿡ Pass
	if (IsEmpty())
		throw EmptyStack();
	top--;
}

template<class ItemType>
ItemType DoubleStack<ItemType>::Top()
{
	if (IsEmpty())
		throw EmptyStack();
	return items[top];
}

template<class ItemType>
void DoubleStack<ItemType>::Print() {

	// ***********
	for (i = 0; i <= top_small; i++) {
		cout << items[i];
	}

	cout << "|"
	for (i = MAX_ITEMS - 1; i >= top_big; i++) {
		cout << items[i];
	}

	cout << "\n";
}