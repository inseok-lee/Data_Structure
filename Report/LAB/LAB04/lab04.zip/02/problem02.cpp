#include <iostream>
#include "StackTType.h"
using namespace std;

void copyStack(StackType<int> stackA, StackType<int>& stackB) {
	StackType<int> stackC;

	while (!stackA.IsEmpty()) {

		int value = stackA.Top();
		stackA.Pop();

		stackC.Push(value);

	}

	while (!stackC.IsEmpty()) {

		int value = stackC.Top();
		stackC.Pop();
		stackA.Push(value);
		stackB.Push(value);

	}


}

int main() {

	StackType<int> stackA;
	StackType<int> stackB;

	stackA.Push(9);
	stackA.Push(8);
	stackA.Push(4);
	stackA.Push(7);
	stackA.Push(5);
	stackA.Push(3);

	copyStack(stackA, stackB);

	while (!stackB.IsEmpty()) {
		int tempItem;
		tempItem = stackB.Top();
		stackB.Pop();
		cout << tempItem << endl;
	}

	return 0;
}

