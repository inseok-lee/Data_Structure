// ItemType.h StackDriver
#ifndef MAXITEMS_H
#define MAXITEMS_H
const int MAX_ITEMS = 10;
#endif MAXITEMS_H