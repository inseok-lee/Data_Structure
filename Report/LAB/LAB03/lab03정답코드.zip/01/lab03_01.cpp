#include <iostream>
using namespace std;

int binary_search(int arr[], int sizeOfArray, int value) {

	int midPoint;
	int first = 0;
	int last = (sizeOfArray - 1);
	bool moreToSearch = (first <= last);
	bool found = false;
	int index = -1;

	while (moreToSearch && !found) {

		midPoint = (first + last) / 2;
		
		if (arr[midPoint] > value) {
			last = midPoint - 1;
			moreToSearch = (first <= last);
		}
		else if (arr[midPoint] < value) {
			first = midPoint + 1;
			moreToSearch = (first <= last);
		}
		else {
			found = true;
			index = midPoint;
			break;
		}
	}

	return index;
}

int binary_search_min(int arr[], int sizeOfArray, int value) {

	int midPoint;
	int first = 0;
	int last = (sizeOfArray - 1);
	bool moreToSearch = (first <= last);
	bool found = false;
	int index = -1;

	while (moreToSearch && !found) {

		midPoint = (first + last) / 2;

		if (arr[midPoint] > value) {
			last = midPoint - 1;
			moreToSearch = (first <= last);
		}
		else if (arr[midPoint] < value) {
			first = midPoint + 1;
			moreToSearch = (first <= last);
		}
		else {
			found = true;
			index = midPoint;
			break;
		}
	}
	if (!found)
		index = first;


	return index;
}

int binary_search_max(int arr[], int sizeOfArray, int value) {

	int midPoint;
	int first = 0;
	int last = (sizeOfArray - 1);
	bool moreToSearch = (first <= last);
	bool found = false;
	int index = -1;

	while (moreToSearch && !found) {

		midPoint = (first + last) / 2;

		if (arr[midPoint] > value) {
			last = midPoint - 1;
			moreToSearch = (first <= last);
		}
		else if (arr[midPoint] < value) {
			first = midPoint + 1;
			moreToSearch = (first <= last);
		}
		else {
			found = true;
			index = midPoint;
			break;
		}
	}
	if (!found)
		index = last;

	return index;
}

int main() {

	
	int list[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

	int result = binary_search(list, 10, 11);

	cout << result << endl;

	result = binary_search(list, 10, 7);

	cout << list[result] << endl;

	int list_2[7] = { 2, 4, 5, 6, 8, 9, 10};

	result = binary_search_min(list_2, 7, 7);
	cout << list_2[result] << endl;

	result = binary_search_max(list_2, 7, 7);
	cout << list_2[result] << endl;
	
	return 0;
}