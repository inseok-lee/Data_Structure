#include <iostream>
#include <string>
using namespace std;
/*
Ǯ�� 1
string function(string str) {
	if (str.find("(") != string::npos) {
		int index = str.find("(");   //�ش� ������ ���� �ε��� ��ȯ
		int end_index = 0;
		int length = str.length();
		while (str.find(")", end_index + 1) != string::npos) {
			end_index = str.find(")", end_index + 1);
			if (end_index == length - 1)
				break;
		}
		string head_str = str.substr(0, index - 1);
		int mul = stoi(str.substr(index - 1, 1));
		string tail_str = function(str.substr(index+1, end_index-index-1));
		string end_str = str.substr(end_index + 1);
		for (int i = 0; i < mul; i++) {
			head_str += tail_str;
		}
		head_str += end_str;
		return head_str;
	}
	else
		return str;
}
*/

//Ǯ�� 2
string recursive(string input) {
	int sidx = input.find('(');
	int eidx = input.rfind(')');
	if (sidx == string::npos) {
		return input;
	}
	else {
		string a = recursive(input.substr(sidx+1, eidx-sidx-1));
		string result = input.substr(0, sidx - 1);
		int n = stoi(input.substr(sidx - 1, 1));
		for (int i = 0; i < n; i++)
			result += a;
		return result;
	} 
}
int main() {
	string result = recursive("33(562(71(9)))");
	cout << result << endl;
	cout << result.length() << endl;
	return 0;
}