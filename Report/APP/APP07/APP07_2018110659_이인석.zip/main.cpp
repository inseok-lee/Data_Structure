#include <iostream>
#include <string>

using namespace std;

string func(string s){
    string concatStr;
    int indexF, indexR;
    bool found = false;

    for(int i = 0; i < s.length(); i++){
        if(s[i] == '('){
            found = true;
        }
    }

    if(found){
        indexF = s.find('(');
        indexR = s.length() - 1;
        int prod = s[indexF-1]-'0';
        string sub;

        concatStr += s.substr(0, indexF-2);

        for(int i = 0; i < prod; i++) {
            concatStr += s.substr(indexF + 1, indexR - 1);
        }
    }
    else{
        return concatStr;
    }

    return func(concatStr);
}


int main() {
    string str;
    cout << "Enter the string: ";
    cin >> str; // str의 길이는 50이하

    func(str);

    cout << "Final string: ";
    cout << str << endl;
    cout << "Length of final string: ";
    cout << str.length() << endl;

    return 0;
}
