#define _CRT_SECURE_NO_WARNINGS 
#include <iostream>
#include "TreeType.h"
#include <string>


using namespace std;

int main() {
    TreeType tree;
    char s1[1000] = "";
    cin.getline(s1, 1000);

    char* ptr = strtok(s1, " ");

    while (ptr != NULL) {
        int tok = atoi(ptr);
        if (tok == -1) {
            tree.LeafDelete();
        }
        else {
            bool found;

            tree.RetrieveItem(tok, found);
            if (found) {
                tree.DeleteItem(tok);
            }
            else {
                tree.InsertItem(tok);
            }
        }
        ptr = strtok(NULL, " ");
    }
    int leafnum;
    leafnum = tree.LeafCount();
    cout << leafnum << endl;

    return 0;
}