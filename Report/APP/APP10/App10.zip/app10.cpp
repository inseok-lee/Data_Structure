#include <iostream>
#include "GraphType.h"
using namespace std;

void dfs(GraphType<int>& graph, int x, bool*& check) {
	QueType<int> vertexQ;
	int vertex;

	graph.GetToVertices(x, vertexQ);
	while (!vertexQ.IsEmpty()) {
		vertexQ.Dequeue(vertex);
		if (!check[vertex]) {
			check[vertex] = true;
			dfs(graph, vertex, check);
		}
		else
			continue;
	}
}

int main() {

	GraphType<int> graph;

	int num, connect;
	cin >> num;
	cin >> connect;

	for(int i = 0; i<num; i++)
		graph.AddVertex(i);
	
	for (int i = 0; i < connect; i++) {
		int a, b;
		cin >> a >> b;
		graph.AddEdge(a, b, 1);
		graph.AddEdge(b, a, 1);
	}

	bool* check = new bool[100];
	for (int i = 0; i < 100; i++) {
		check[i] = false;
	}
	check[0] = true;

	dfs(graph, 0, check);

	int count = 0;
	for (int i = 0; i < 100; i++) {
		if (check[i])
			count++;
	}
	cout << count << endl;

	return 0;
}