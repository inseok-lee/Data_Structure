// ItemType.h StackDriver
const int MAX_ITEMS = 20;
typedef char ItemType;