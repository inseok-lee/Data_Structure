#include <iostream>
#include "TreeType.h"

using namespace std;

int main() {
	int N, k, M;
	TreeType T;
	cin >> N;
	for (int i = 0; i < N; i++) {
		cin >> k;
		T.InsertItem(k);
	}
	cin >> M;
	for (int i = 0; i < M; i++) {
		T.remove_small();
	}

	cout << T.LeafCount();

	return 0;
}