#include <iostream>
#include "QueType.h"
using namespace std;

int main() {
    QueType que;
    QueType tempq;
    int item;
    int countNum = 0;
    cin >> countNum;
    
    for (int i = 0 ; i < countNum; i++){
        que.Enqueue(i + 1);
    }
    
    int checker = 0;
    while(!que.IsEmpty()){
        if(que.Length() == 1){
            break;
        }

        if(checker == 0){
            que.Dequeue(item);
//            cout << "que_Dequeue : " << item << endl;
            tempq.Enqueue(item);
//            cout << "temp_que_Enqueue : " << item << endl;
            checker = 1;
        }
        else{
            que.Dequeue(item);
//            cout << "que_Dequeue : " << item << endl;
            que.Enqueue(item);
//            cout << "que_Enqueue : " << item << endl;
            checker = 0;
        }
    }
    que.Dequeue(item);
    tempq.Enqueue(item);
    
    while(!tempq.IsEmpty()){
        tempq.Dequeue(item);
        cout << item << " ";
    }
    
    return 0;
}
