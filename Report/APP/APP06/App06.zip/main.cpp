#include <iostream>
#include <string.h>
using namespace std;
#include "StackType.h"

int main() {
	StackType left_stack;
	StackType right_stack;

	char* input = new char[100];
	cin >> input;

	for (int i = 0; i < 100; i++) {
		char c = input[i];
		if (c == NULL)
			break;

		switch (c) {
		case '<':
			if (!left_stack.IsEmpty()) {
				char tmp;
				tmp = left_stack.Top();
				left_stack.Pop();
				right_stack.Push(tmp);
			}
			break;

		case '>':
			if (!right_stack.IsEmpty()) {
				char tmp;
				tmp = right_stack.Top();
				right_stack.Pop();
				left_stack.Push(tmp);
			}
			break;

		case '-':
			if (!left_stack.IsEmpty()) {
				left_stack.Pop();
			}
			break;

		default:
			left_stack.Push(c);
			break;
		}
	}

	while (!left_stack.IsEmpty()) {
		char tmp;
		tmp = left_stack.Top();
		left_stack.Pop();
		right_stack.Push(tmp);
	}

	while (!right_stack.IsEmpty()) {
		char tmp;
		tmp = right_stack.Top();
		right_stack.Pop();
		cout << tmp;
	}
	cout << endl;

	return 0;
}
/*
int main() {
	UnsortedType<char> us_list;
	UnsortedType<char> tmp_list;

	int n;
	cin >> n;
	int cursor = 0;

	for (int i = 0; i < n; i++) {
		char c;
		cin >> c;
		

		if (c == '<') {
			char tmp;
			us_list.RemoveTop(tmp);
			tmp_list.InsertItem(tmp);
		}
		else if(c == '>') {
			cursor += 1;
			if (cursor < us_list.LengthIs())
				cursor = us_list.LengthIs();
		}
		else {
			us_list.InsertItem(c);
			cursor += 1;
		}
	}

	us_list.InsertItem(1);
	us_list.InsertItem(2);
	us_list.InsertItem(1);
	us_list.InsertItem(2);
	us_list.InsertItem(3);
	us_list.InsertItem(4);
	us_list.InsertItem(1);
	us_list.InsertItem(2);

	us_list.DeleteItem(5);

	int length = 0;
	int item;
	us_list.ResetList();
	while (length != us_list.LengthIs()) {

		us_list.GetNextItem(item);

		cout << item << endl;
		length++;
	}

	return 0;
}
*/